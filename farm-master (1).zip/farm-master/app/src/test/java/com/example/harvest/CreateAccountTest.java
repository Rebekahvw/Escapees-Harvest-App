package com.example.harvest;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;


public class CreateAccountTest {


    @Test
    public void creationWorks() {

    }
}
